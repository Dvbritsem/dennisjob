<?php

if (isset($_POST['adminsend'])) {

    require 'database.php';

    $adminmail = mysqli_real_escape_string($conn, $_POST['adminmail']);
    $admincode = mysqli_real_escape_string($conn, $_POST['admincode']);

    if (empty($adminmail) || empty($admincode)) {
        header("Location: ../index.php?emptyfields");
        exit();
    }
    else {
        $sql = "SELECT * FROM admins WHERE adminmail=?;";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("Location: ../index.php?sqlerror");
            exit();
        }
        else {

            mysqli_stmt_bind_param($stmt, "s", $adminmail);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if ($row = mysqli_fetch_assoc($result)) {
                $codehash = password_hash($row['admincode'], PASSWORD_DEFAULT);
                $codecheck = password_verify($admincode, $codehash);
                if ($codecheck == false) {
                    header("Location: ../index.php?wrongcode");
                    exit();
                }
                else if($codecheck == true) {
                    session_start();
                    $_SESSION['adminid'] = $row['adminid'];
                    header("Location: ../index.php?login=succes");
                    exit();
                }
                else {
                    header("Location: ../index.php?WrongCode");
                    exit();
                }
            }
            else {
                header("Location: ../index.php?NoUser");
                exit();
            }
        }
    }
}
else {
    header("Location: ../index.php");
    exit();
}