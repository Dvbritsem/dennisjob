<?php

if (isset($_POST['usersend'])) {

    require 'database.php';

    $usermail = mysqli_real_escape_string($conn, $_POST['usermail']);
    $usercode = mysqli_real_escape_string($conn, $_POST['usercode']);

    if (empty($usermail) || empty($usercode)) {
        header("Location: ../index.php?emptyfields");
        exit();
    }
    else {
        $sql = "SELECT * FROM user WHERE usermail=?;";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("Location: ../index.php?sqlerror");
            exit();
        }
        else {

            mysqli_stmt_bind_param($stmt, "s", $usermail);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            if ($row = mysqli_fetch_assoc($result)) {
                $codehash = password_hash($row['usercode'], PASSWORD_DEFAULT);
                $codecheck = password_verify($usercode, $codehash);
                if ($codecheck == false) {
                    header("Location: ../index.php?wrongcode");
                    exit();
                }
                else if($codecheck == true) {
                    session_start();
                    $_SESSION['userid'] = $row['userid'];
                    $_SESSION['usermail'] = $row['usermail'];
                    header("Location: ../index.php?login=succes");
                    exit();
                }
                else {
                    header("Location: ../index.php?wrongcode");
                    exit();
                }
            }
            else {
                header("Location: ../index.php?nouser");
                exit();
            }
        }
    }
}
else {
    header("Location: ../index.php");
    exit();
}