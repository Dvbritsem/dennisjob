<?php
session_start();
if (!isset($_SESSION['adminid']) && isset($_POST['searchuser'])) {
    header("Location: ../index.php");
    exit();
}

require 'database.php';

$searchuserid = mysqli_real_escape_string($conn, $_POST['searchuserid']);
$newusermail = mysqli_real_escape_string($conn, $_POST['newusermail']);
$newusername = mysqli_real_escape_string($conn, $_POST['newusername']);
$newbirthday = mysqli_real_escape_string($conn, $_POST['newbirthday']);

if (isset($_POST['searchuser']) && !$_SESSION['founduser']) {
    if (empty($searchuserid)) {
        header("Location: ../index.php?emptyfields");
        exit();
    }

    $sql = "SELECT * FROM user WHERE userid=" . $searchuserid . ";";
    $result = mysqli_query($conn, $sql);
    $resultcheck = mysqli_num_rows($result);

    if ($resultcheck > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $_SESSION['foundusername'] = $row['username'];
            $_SESSION['foundusermail'] = $row['usermail'];
            $_SESSION['foundbirthday'] = $row['birthday'];

            $_SESSION['founduser'] = $_POST['searchuser'];
            $_SESSION['founduserid'] = $searchuserid;
            header("location: ../index.php?SearchComplete");
            exit();
        }
    }
    else {
        header("location: ../index.php?NoUserFound");
        exit();
    }
}
if (isset($_POST['DataSave'])) {
    if (empty($newusermail) || empty($newusername) || empty($newbirthday)) {
        header("Location: ../index.php?emptyfields");
        exit();
    }

    if ($newusermail == $_SESSION['foundusermail'] || !mysqli_num_rows($result) > 0) {
        $sql2 = "UPDATE user SET username='$newusername', usermail='$newusermail', birthday='$newbirthday' WHERE userid=" .$_SESSION['founduserid']. ";";
        $result2 = mysqli_query($conn, $sql2);

        if (isset($result2) == true) {
            unset($_SESSION['founduser']);
            header("Location: ../index.php?ProfileSaved");
            exit();
        }
    }
    else {
        header("Location: ../index.php?E-Mail_Already_Taken");
        exit();
    }
}
elseif (isset($_POST['UserDelete'])) {
    $sql3 = "DELETE FROM user WHERE userid=" .$_SESSION['founduserid']. ";";
    $result3 = mysqli_query($conn, $sql3);

    if (isset($result3) == true) {
        unset($_SESSION['founduser']);
        header("Location: ../index.php?test");
        exit();
    }
}
