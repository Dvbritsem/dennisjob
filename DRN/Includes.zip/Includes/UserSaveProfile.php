<?php
session_start();
if (!isset($_SESSION['userid']) && isset($_POST['DataSave'])) {
    header("Location: ../index.php");
    exit();
}

require 'database.php';

$newusermail = mysqli_real_escape_string($conn, $_POST['newusermail']);
$newusername = mysqli_real_escape_string($conn, $_POST['newusername']);
$newbirthday = mysqli_real_escape_string($conn, $_POST['newbirthday']);

$sql = "SELECT * FROM user WHERE usermail='$newusermail'";
$result = mysqli_query($conn, $sql);

if (empty($newusermail) || empty($newusername) || empty($newbirthday)) {
    header("Location: ../index.php?emptyfields");
    exit();
}

if ($newusermail == $_SESSION['usermail'] || !mysqli_num_rows($result) > 0) {
    $sql2 = "UPDATE user SET username='$newusername', usermail='$newusermail', birthday='$newbirthday' WHERE userid=". $_SESSION['userid'] .";";
    $result2 = mysqli_query($conn, $sql2);

    if (isset($result2) == true) {
        header("Location: ../index.php?ProfileSaved");
        exit();
    }
}
else {
    header("Location: ../index.php?E-Mail_Already_Taken");
    exit();
}